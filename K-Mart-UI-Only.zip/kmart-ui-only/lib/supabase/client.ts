/**
 * UI-only local backend mock.
 * This file intentionally contains no Supabase/network dependency.
 * It keeps the existing UI components runnable without a database.
 */

type MockUser = {
  id: string;
  phone?: string;
  email?: string;
  user_metadata?: Record<string, unknown>;
};

type Listener = (event: string, session: { user: MockUser } | null) => void;

let currentUser: MockUser | null = null;
let pendingPhone = '';
const listeners = new Set<Listener>();

if (typeof window !== 'undefined') {
  try {
    const saved = localStorage.getItem('kmart_ui_mock_user');
    if (saved) currentUser = JSON.parse(saved);
  } catch {}
}

function persistUser() {
  if (typeof window === 'undefined') return;
  try {
    if (currentUser) localStorage.setItem('kmart_ui_mock_user', JSON.stringify(currentUser));
    else localStorage.removeItem('kmart_ui_mock_user');
  } catch {}
}

function emit(event: string) {
  const session = currentUser ? { user: currentUser } : null;
  listeners.forEach((listener) => listener(event, session));
}

function mockQueryResult() {
  return { data: [], error: null, count: 0 };
}

function createQueryChain() {
  const chain: any = {};
  const methods = [
    'select', 'insert', 'update', 'upsert', 'delete', 'eq', 'neq', 'gt', 'gte',
    'lt', 'lte', 'in', 'is', 'ilike', 'like', 'or', 'order', 'limit', 'range',
    'match', 'filter', 'contains', 'overlaps', 'single', 'maybeSingle', 'csv',
  ];

  for (const method of methods) {
    chain[method] = (...args: unknown[]) => {
      if (method === 'single' || method === 'maybeSingle') {
        chain.__single = true;
      }
      return chain;
    };
  }

  chain.then = (resolve: (value: unknown) => unknown, reject?: (reason: unknown) => unknown) => {
    try {
      const result = chain.__single
        ? { data: null, error: null, count: null }
        : mockQueryResult();
      return Promise.resolve(result).then(resolve, reject);
    } catch (error) {
      return Promise.reject(error).then(resolve, reject);
    }
  };

  chain.catch = (reject: (reason: unknown) => unknown) => Promise.resolve(mockQueryResult()).catch(reject);
  return chain;
}

const auth = {
  async signInWithOtp({ phone }: { phone: string }) {
    pendingPhone = phone;
    return { data: { messageId: 'ui-only-demo' }, error: null };
  },

  async verifyOtp({ phone, token }: { phone: string; token: string; type?: string }) {
    if (!/^\d{6}$/.test(token)) {
      return { data: null, error: { message: 'Invalid OTP', code: 'invalid_otp' } };
    }

    const normalizedPhone = phone || pendingPhone;
    currentUser = {
      id: `demo-user-${normalizedPhone.replace(/\D/g, '') || 'guest'}`,
      phone: normalizedPhone,
      user_metadata: { full_name: 'K MART Customer' },
    };
    pendingPhone = '';
    persistUser();
    emit('SIGNED_IN');
    return { data: { user: currentUser, session: { user: currentUser } }, error: null };
  },

  async getUser() {
    return { data: { user: currentUser }, error: null };
  },

  async getSession() {
    return { data: { session: currentUser ? { user: currentUser } : null }, error: null };
  },

  onAuthStateChange(callback: Listener) {
    listeners.add(callback);
    return { data: { subscription: { unsubscribe: () => listeners.delete(callback) } } };
  },

  async signOut() {
    currentUser = null;
    pendingPhone = '';
    persistUser();
    emit('SIGNED_OUT');
    return { error: null };
  },

  async updateUser(updates: Record<string, unknown>) {
    currentUser = currentUser || { id: 'demo-user-guest' };
    currentUser = { ...currentUser, ...updates };
    persistUser();
    emit('USER_UPDATED');
    return { data: { user: currentUser }, error: null };
  },

  async exchangeCodeForSession() {
    return { data: { session: currentUser }, error: null };
  },
};

export function createClient() {
  return supabase;
}

export const supabase: any = {
  auth,
  from: (_table: string) => createQueryChain(),
  rpc: async (_name: string, _args?: unknown) => ({ data: null, error: null }),
  functions: {
    async invoke(name: string, options?: { body?: any }) {
      if (name === 'checkout') {
        const body = options?.body || {};
        const total = Number(body.total || 0);
        return {
          data: {
            order: {
              id: `demo-order-${Date.now()}`,
              order_number: `KM-${String(Math.floor(100000 + Math.random() * 900000))}`,
              order_type: body.orderType || 'DELIVERY',
              pickup_store_id: body.pickupStoreId || null,
              total,
              status: 'CONFIRMED',
              created_at: new Date().toISOString(),
            },
          },
          error: null,
        };
      }
      return { data: null, error: null };
    },
  },
  removeChannel: (_channel: unknown) => undefined,
};
