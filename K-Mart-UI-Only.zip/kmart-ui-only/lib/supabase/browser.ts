import { supabase, createClient } from './client';

export function createSupabaseBrowserClient() {
  return supabase;
}

export { createClient };
