@echo off
cd /d "%~dp0"
echo Installing UI dependencies...
npm install
if errorlevel 1 (
  echo.
  echo npm install failed. Check Node.js and npm, then run: npm install
  pause
  exit /b 1
)
echo.
echo Starting K MART UI...
npm run dev
