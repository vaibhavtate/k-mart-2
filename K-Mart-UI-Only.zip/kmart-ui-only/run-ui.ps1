Set-Location $PSScriptRoot
npm install
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
npm run dev
