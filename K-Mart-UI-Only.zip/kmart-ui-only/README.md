# K MART — UI Only

This package is the K MART frontend/UI separated from the backend integration.

## Included
- Next.js pages and components
- Tailwind styling
- Local mock data
- Local UI state for cart, addresses, wishlist, login demo, and orders
- No Supabase credentials
- No API routes
- No database
- No middleware

## Run

```bash
npm install
npm run dev
```

Then open `http://localhost:3000`.

### UI login demo
Enter any valid 10-digit Indian mobile number. For the demo OTP, enter any 6 digits.

This is a UI/demo build. Real SMS authentication, database persistence, server checkout, and server payment verification are intentionally not included.
